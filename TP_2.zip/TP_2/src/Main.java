public class Main {
    public static void main(String[] args) {
        double distance = 150.0;
        Vehicule[] vehicules = {
                new Voiture(),
                new Velo(),
                new Bateau()
        };
        for (Vehicule v : vehicules) {
            System.out.println("Temps de trajet pour " + v.getClass().getSimpleName() + ": " + v.calculerTempsTrajet(distance) + " heures");
        }
    }
}
