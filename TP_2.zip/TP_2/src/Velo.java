class Velo extends Vehicule {
    public Velo() {
        this.vitesseMoyenne = 15.0;  // Velo speed is 15 km/h
    }
    @Override
    public double calculerTempsTrajet(double distance) {
        return distance / vitesseMoyenne;
    }
}
