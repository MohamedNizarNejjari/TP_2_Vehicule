class Bateau extends Vehicule {
    public Bateau() {
        this.vitesseMoyenne = 40.0;
    }
    @Override
    public double calculerTempsTrajet(double distance) {
        return distance / vitesseMoyenne;
    }
}
