class Voiture extends Vehicule {
    public Voiture() {
        this.vitesseMoyenne = 100.0;
    }
    @Override
    public double calculerTempsTrajet(double distance) {

        return distance / vitesseMoyenne;
    }
}
