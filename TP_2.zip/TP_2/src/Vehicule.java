abstract class Vehicule {
    protected double vitesseMoyenne;
    public abstract double calculerTempsTrajet(double distance);
}
